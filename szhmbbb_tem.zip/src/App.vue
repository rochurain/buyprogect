<template>
  <div id="app">
      helloworld
  </div>
</template>

<script>
export default {
  name: 'app',
}
</script>

<style>

</style>
